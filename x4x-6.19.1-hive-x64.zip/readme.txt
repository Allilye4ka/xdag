
   _  __ __  _______  _          __ __     _  __ ____  ___   ______
  | |/ //  |/  / __ \(_)___ _   / // /    | |/ // __ \/   | / ____/
  |   // /|_/ / /_/ / / __ `/  / // /_    |   // / / / /| |/ / __  
 /   |/ /  / / _, _/ / /_/ /  /__  __/   /   |/ /_/ / ___ / /_/ /  
/_/|_/_/  /_/_/ |_/_/\__, /     /_/     /_/|_/_____/_/  |_\____/   
                    /____/                                         

------------------------------------------------------[ Abstract ]---

XMRig 4 XDAG (also known as X4X) is a XMRig fork that incorporates
the RandomX algorithm variant for XDAG.

----------------------------------------------------[ This build ]---

[Versioning] : 6.19.1 / branch 'master'
[Compilator] : gcc/7.5.0
[Libraries ] : libuv/1.44.2 OpenSSL/1.1.1s hwloc/2.9.0
[Target  OS] : HiveOS 0.6 or above
[Repository] : https://github.com/FSOL-XDAG/xmrig-4-xdag

----------------------------------------------------[ How to use ]---

[ 1 ] On HiveOS web :

  * Create new FS
  * Specify your wallet, pool, and worker name as password.
  * Activate "CPU on"
  * Choose “XMRig-new” and as fork “XMRig” (not XMRig-CC)
  
[ 2 ] On HiveOS web :
 
  * miner stop
  * cp xmrig-4-xdag /hive/miners/xmrig-new/xmrig/6.19.0/xmrig
  * miner start

[ More info ]

  https://medium.com/@fsol/mining-xdag-on-hiveos-d274485e3e10

-----------------------------------------------------[ Need help ]---

https://discord.gg/fHE4sJ7NKt

-----------------------------------------------------[ Thanks to ]---

XMRig & XDAG development teams.

